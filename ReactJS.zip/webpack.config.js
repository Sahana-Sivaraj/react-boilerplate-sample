'use strict';
const path = require("path");
const webpack = require('webpack');
const HtmlWebpackPlugin = require('html-webpack-plugin')
var DIST_DIR = path.resolve(__dirname, './dist');
var SRC_DIR = path.resolve(__dirname, './src');

module.exports  = {
    entry:  SRC_DIR+'/sample.jsx',
    output: {
        path: DIST_DIR,
        filename: "transpiled.js",
        publicPath: "/dist/"
    },
    devtool: 'source-map',
    devServer: {
      inline: true,
      port: 3010,
      hot: true,
      inline: true,
      progress: true,
      historyApiFallback: true
    },
    module: {
        loaders: [
            {
                test: /\.js[x]$/,
                include: SRC_DIR,
                loaders: 'babel-loader',
                exclude:/node_modules/,
                query: {
                    presets: ["react", "es2015", "stage-0","stage-2"]
                }
            },
          
        ]
    },
    resolve: {
        extensions: ['*', '.js', '.jsx']
      },
      plugins: [
        new webpack.HotModuleReplacementPlugin(),
       
      ]
};
