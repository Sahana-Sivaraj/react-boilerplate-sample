import React, { Component } from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
// import ReactDOM from 'react-dom';
class App extends Component {
   render() {
      return (
          <div>
         <Router>
            <div>
               <h2>Welcome to React Router Tutorial</h2>
               <ul>
                  <li><Link to='/'>Home</Link></li>
                  <li><Link to='/Login'>Login</Link></li>
               </ul>
               <hr />
               
               <Switch>
                  <Route exact path='/' component={Register} />
                  <Route exact path='/Login' component={Login} />
               </Switch>
            </div>
         </Router>
         </div>
      );
   }
}

 function Register(props) {
    function myFunction() {
        var x = document.getElementById("content");
        if (x.style.display === "none") {
            x.style.display = "block";
        } else {
            x.style.display = "none";
        }
    }
    return <div>
      <div id='content'>Home</div>
      <button onClick={myFunction}>Close Me</button>
     </div>;
 }
  
function Login(props) {
    return <h1>Login</h1>;
}

export default App;