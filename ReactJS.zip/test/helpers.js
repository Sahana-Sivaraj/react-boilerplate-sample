// import { expect } from 'chai';
var expect=require('chai').expect;
// import { sinon, spy } from 'sinon';
var spy=require('sinon').spy;
var sinon=require('sinon');
//import { mount, render, shallow } from 'enzyme';
var mount=require('enzyme').mount;
var render=require('enzyme').render;
var shallow=require('enzyme').shallow;

global.expect = expect;
global.sinon = sinon;
global.spy = spy;

global.mount = mount;
global.render = render;
global.shallow = shallow;