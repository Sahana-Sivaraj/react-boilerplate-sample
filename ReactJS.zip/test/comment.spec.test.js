import React from 'react';
import Comment from '../src/comment';

describe('Comment item', () => {
 
  it('is of type <li>', () => {
    expect(shallow(<Comment />)).contains( <li className='comment-item'/>).to.equal(true);
  });
});


